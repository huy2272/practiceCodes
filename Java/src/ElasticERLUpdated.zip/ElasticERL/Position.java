package ElasticERL;

abstract class Position<E> {
	abstract E getElement();
}
